#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate RSA key pair and signed root-hub license.")
    parser.add_argument("--out-dir", default="config", help="Output directory")
    parser.add_argument("--expiry", default="2099-12-31", help="License expiry YYYY-MM-DD")
    parser.add_argument("--max-servers", type=int, default=0, help="0 means unlimited")
    args = parser.parse_args()

    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()

    data = {
        "expiry": args.expiry,
        "max_servers": args.max_servers,
        "features": {
            "unlimited_servers": args.max_servers <= 0,
        },
    }
    message = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    signature = private_key.sign(message, padding.PKCS1v15(), hashes.SHA256())

    license_payload = {
        "data": data,
        "signature": base64.b64encode(signature).decode("ascii"),
    }

    (out_dir / "private_key_DO_NOT_SHIP.pem").write_bytes(
        private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    (out_dir / "public.pem").write_bytes(
        public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )
    (out_dir / "license.json").write_text(
        json.dumps(license_payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"Generated license in {out_dir}")
    print("max_servers <= 0 means unlimited")
    print("Keep private_key_DO_NOT_SHIP.pem outside production/runtime installs.")


if __name__ == "__main__":
    main()
