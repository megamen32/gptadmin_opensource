# root-hub license refactor

Внутри:

- `hub_proxy.py` — обновлённый hub-прокси.
- `licensing/` — отдельный независимый модуль лицензирования.
- `config/license.json` — тестовая подписанная лицензия `max_servers=0`, то есть unlimited.
- `config/public.pem` — публичный ключ для проверки этой тестовой лицензии.
- `config/private_key_DO_NOT_SHIP.pem` — приватный ключ только для локальной генерации тестовых лицензий. Не класть на production-сервер.
- `generate_license.py` — генератор пары ключей и подписанного `license.json`.

## Запуск рядом с папкой `config/`

```bash
python hub_proxy.py
```

## Явные пути

```bash
export LICENSE_FILE=/etc/root-hub/license.json
export PUBLIC_KEY_FILE=/etc/root-hub/public.pem
python hub_proxy.py
```

## Unlimited-лицензия

В `licensing/policy.py` принято правило:

```python
max_servers <= 0 означает unlimited
```

Поэтому такая лицензия не ограничивает количество серверов:

```json
{
  "expiry": "2099-12-31",
  "max_servers": 0
}
```

## Куда переносить в проекте

Скопировать:

```text
hub_proxy.py
licensing/
config/license.json
config/public.pem
```

Приватный ключ в рабочий проект лучше не переносить.
