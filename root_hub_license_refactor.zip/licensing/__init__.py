from __future__ import annotations

import logging

from .errors import (
    LicenseError,
    LicenseExpiredError,
    LicenseLimitExceededError,
    LicenseLoadError,
    LicenseVerificationError,
)
from .policy import LicensePolicy
from .provider import license_file_from_env, public_key_file_from_env
from .verifier import load_and_verify_license

log = logging.getLogger("licensing")


class LicenseService:
    def __init__(self, policy: LicensePolicy):
        self.policy = policy

    @classmethod
    def from_env(cls) -> "LicenseService":
        license_file = license_file_from_env()
        public_key_file = public_key_file_from_env()
        verified_license = load_and_verify_license(
            license_file=license_file,
            public_key_file=public_key_file,
        )
        log.info(
            "license: OK file=%s pub=%s expiry=%s max_servers=%s",
            license_file,
            public_key_file,
            verified_license.data.expiry,
            verified_license.data.max_servers,
        )
        return cls(LicensePolicy(verified_license))

    def ensure_allowed(self, *, current_servers: int) -> None:
        self.policy.ensure_allowed(current_servers=current_servers)


__all__ = [
    "LicenseService",
    "LicenseError",
    "LicenseLoadError",
    "LicenseVerificationError",
    "LicenseExpiredError",
    "LicenseLimitExceededError",
]
