from __future__ import annotations

import base64
import json
from datetime import datetime
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from .errors import LicenseLoadError, LicenseVerificationError
from .models import LicenseData, VerifiedLicense


def load_and_verify_license(
    *,
    license_file: Path,
    public_key_file: Path,
) -> VerifiedLicense:
    try:
        public_key = serialization.load_pem_public_key(public_key_file.read_bytes())
        license_payload = json.loads(license_file.read_text(encoding="utf-8"))
    except Exception as exc:
        raise LicenseLoadError(
            f"Cannot load license files: license={license_file}, public_key={public_key_file}, error={exc}"
        ) from exc

    try:
        data = license_payload["data"]
        signature = base64.b64decode(license_payload["signature"])

        message = json.dumps(
            data,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

        public_key.verify(
            signature,
            message,
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
    except Exception as exc:
        raise LicenseVerificationError(f"Bad license signature: {exc}") from exc

    expiry_raw = data.get("expiry")
    expiry = None
    if expiry_raw:
        expiry = datetime.strptime(expiry_raw, "%Y-%m-%d").date()

    max_servers_raw = data.get("max_servers")
    max_servers = int(max_servers_raw) if max_servers_raw is not None else None

    return VerifiedLicense(
        data=LicenseData(
            expiry=expiry,
            max_servers=max_servers,
            features=data.get("features", {}),
            raw=data,
        ),
        source=str(license_file),
    )
