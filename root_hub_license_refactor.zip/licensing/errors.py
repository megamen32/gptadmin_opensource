class LicenseError(Exception):
    """Base license error."""


class LicenseLoadError(LicenseError):
    """License file or public key could not be loaded."""


class LicenseVerificationError(LicenseError):
    """License signature is invalid."""


class LicenseExpiredError(LicenseError):
    """License expiry date is in the past."""


class LicenseLimitExceededError(LicenseError):
    """License limit has been exceeded."""
