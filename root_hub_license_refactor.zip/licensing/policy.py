from __future__ import annotations

import datetime

from .errors import LicenseExpiredError, LicenseLimitExceededError
from .models import VerifiedLicense


class LicensePolicy:
    def __init__(self, license_: VerifiedLicense):
        self.license = license_

    def ensure_not_expired(self) -> None:
        expiry = self.license.data.expiry
        if expiry is None:
            return

        today = datetime.date.today()
        if today > expiry:
            raise LicenseExpiredError(f"License expired: {expiry.isoformat()}")

    def ensure_server_limit(self, current_servers: int) -> None:
        max_servers = self.license.data.max_servers

        if max_servers is None:
            return

        # max_servers <= 0 means unlimited.
        if max_servers <= 0:
            return

        if current_servers > max_servers:
            raise LicenseLimitExceededError(
                f"Too many servers: {current_servers}/{max_servers}"
            )

    def ensure_allowed(self, *, current_servers: int) -> None:
        self.ensure_not_expired()
        self.ensure_server_limit(current_servers)
