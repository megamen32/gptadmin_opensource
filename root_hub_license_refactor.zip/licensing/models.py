from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any


@dataclass(frozen=True)
class LicenseData:
    expiry: date | None
    max_servers: int | None
    features: dict[str, Any]
    raw: dict[str, Any]


@dataclass(frozen=True)
class VerifiedLicense:
    data: LicenseData
    source: str
