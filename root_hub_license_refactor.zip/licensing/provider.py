from __future__ import annotations

import os
from pathlib import Path


APP_CONFIG_DIR_NAME = "root-hub"


def default_config_dir() -> Path:
    """
    Cross-platform config lookup order:
    1. LICENSE_CONFIG_DIR
    2. ./config from the current working directory
    3. ~/.config/root-hub
    """
    if value := os.getenv("LICENSE_CONFIG_DIR"):
        return Path(value).expanduser().resolve()

    local_config = Path.cwd() / "config"
    if local_config.exists():
        return local_config.resolve()

    return (Path.home() / ".config" / APP_CONFIG_DIR_NAME).resolve()


def license_file_from_env() -> Path:
    return Path(
        os.getenv("LICENSE_FILE", str(default_config_dir() / "license.json"))
    ).expanduser().resolve()


def public_key_file_from_env() -> Path:
    return Path(
        os.getenv("PUBLIC_KEY_FILE", str(default_config_dir() / "public.pem"))
    ).expanduser().resolve()
