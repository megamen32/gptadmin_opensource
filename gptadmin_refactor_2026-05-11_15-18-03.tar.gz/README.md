# GPTAdmin Services

This repository contains two small services used to remotely control a machine.

* **services/rootd.py** – runs as root and exposes low level operations.
* **services/rootd_pure.py** – simplified variant of `rootd` that depends only on the
  Python standard library and works on any Unix-like system including macOS.
* **services/hub_proxy.py** – collects heartbeats from multiple `rootd` servers and
  proxies requests to them.

## Requirements

```
pip install -r requirements.txt
```

## Installation with ngrok

For an automated setup that installs dependencies, configures systemd units,
and exposes the hub through ngrok, run:

```
./deploy/install_with_ngrok.sh
```

The script prompts for:

* a Bearer token used by both `rootd` and `hub_proxy`;
* an ngrok token to publish the proxy.

It downloads the packaged application, creates virtual environment, installs
dependencies, writes systemd units for `rootd`, `hub_proxy` and an ngrok
forwarder, then starts all services. The public URL returned by ngrok is
displayed and stored in `ngrok_url.txt` inside the installation directory.

## Running

Start `rootd` and `hub_proxy` in separate terminals:

```
ROOTD_TOKEN=srv_secret python services/rootd.py
CTL_TOKEN=chatgpt_secret python services/hub_proxy.py
```

`rootd` can register itself with the hub when `HUB_URL` is set. Each service
accepts tokens through environment variables as shown above.

To run the minimal version that requires no external dependencies use:

```
ROOTD_TOKEN=srv_secret python services/rootd_pure.py
```

Set `QUEUE_URL` to enable polling mode. In this mode the daemon polls the
queue for tasks and does not start an HTTP server:

```
QUEUE_URL=http://hub:9001/queue ROOTD_TOKEN=srv_secret python services/rootd_pure.py
```

### SSH backend

If `rootd` should execute commands on a remote host instead of locally,
set `SSH_HOST` (and optionally `SSH_PORT`, `SSH_USER`, `SSH_PASSWORD` or
`SSH_KEY`) before starting the service. The server will connect over SSH and
run all commands on that host.

## Build & Obfuscation

The repository includes a helper script to create obfuscated, distributable
executables of both services using [PyArmor](https://github.com/dashingsoft/pyarmor).

```
./tools/build.sh
```

Artifacts will be placed in the `build/` directory (packed into
`gptadmin.tar.gz`).  The script performs a small smoke test to ensure the
generated binaries start and respond to basic requests.

### Rotating or revoking tokens

Tokens are stored inside the systemd unit files. To change or revoke a token
edit the relevant unit, update `ROOTD_TOKEN` or `CTL_TOKEN` and restart the
service:

```
sudo systemctl edit --full rootd.service
sudo systemctl restart rootd
```

Repeat for `hub_proxy.service`. Removing a token and restarting effectively
revokes access. Remember to also update any clients that rely on the old token.

## Tests

Basic scripts for manual testing are provided:

```
python services/hub_proxy.py & python services/rootd.py &
python tests/test_rootd.py
python tests/test_hub.py
```

## public/openapi.json

`public/openapi.json` documents the API served by `hub_proxy`. It was produced manualy, update it whenever the API changes to refresh the schema.
