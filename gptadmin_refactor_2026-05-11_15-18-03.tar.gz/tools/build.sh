#!/usr/bin/env bash
# Incremental & robust build with auto --collect-all and logs in build/

set -Eeuo pipefail

# Always run from repo root.
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"

# ---------- pretty xtrace ----------
export PS4='+ [${EPOCHREALTIME}] ${BASH_SOURCE##*/}:${LINENO}: '
set -x
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
export PYTHONUTF8=1

ART_DIR="build"
CACHE_DIR=".buildcache"
LOG="$ART_DIR/build.log"
ROOTD_RT_LOG="$ART_DIR/rootd_runtime.log"
HUB_RT_LOG="$ART_DIR/hub_runtime.log"

ROOTD_PID=""
HUB_PID=""

FORCE="${FORCE:-0}"                    # 1 = force rebuild components regardless of fingerprint
CLEAN="${CLEAN:-0}"                    # 1 = full clean of build/ and cache
REBUILD_ON_REQ_CHANGE="${REBUILD_ON_REQ_CHANGE:-0}"  # 1 = include requirements.txt into fingerprints
SKIP_TESTS="${SKIP_TESTS:-0}"          # 1 = skip smoke tests

# ---------- clean or keep previous build ----------
if [[ "$CLEAN" == "1" ]]; then
  rm -rf "$ART_DIR" "$CACHE_DIR"
fi
mkdir -p "$ART_DIR/cli" "$CACHE_DIR"

# ---------- tee to build/build.log ----------
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

cleanup() {
  set +e
  echo "== cleanup ==" | tee -a "$LOG"
  [[ -n "$ROOTD_PID" ]] && kill "$ROOTD_PID" 2>/dev/null || true
  [[ -n "$HUB_PID"   ]] && kill "$HUB_PID"   2>/dev/null || true
}
trap cleanup EXIT

err_report() {
  local exit_code=$?
  local cmd="${BASH_COMMAND:-unknown}"
  echo
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "BUILD FAILED (exit=$exit_code)"
  echo "Last command: $cmd"
  echo "File: ${BASH_SOURCE[1]:-?}  Line: ${BASH_LINENO[0]:-?}  Func: ${FUNCNAME[1]:-main}"
  echo "---- tail of $LOG ----------------------------------------------------"
  tail -n 200 "$LOG" || true
  echo "---------------------------------------------------------------------"
  echo "Runtime logs (if any):"
  [[ -f "$ROOTD_RT_LOG" ]] && { echo "--- rootd_runtime.log (tail) ---"; tail -n 120 "$ROOTD_RT_LOG"; }
  [[ -f "$HUB_RT_LOG"   ]] && { echo "--- hub_runtime.log (tail) ---";   tail -n 120 "$HUB_RT_LOG"; }
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  exit "$exit_code"
}
trap err_report ERR

step(){ echo; echo "===== $* ====="; }
need(){ command -v "$1" >/dev/null 2>&1 || { echo "ERROR: missing command: $1"; exit 127; }; }

# ---------- tooling ----------
step "Check tooling"
need curl; need python; need pip; need tar; need grep; need sed; need awk; need sha256sum

# ---------- include CLI ----------
step "Include gptadmin.py"
CLI_SRC="cli/gptadmin.py"
if [[ -f "$CLI_SRC" ]]; then
  cp "$CLI_SRC" "$ART_DIR/cli/"
else
  echo "WARN: $CLI_SRC not found; continuing without it"
fi

# ---------- venv ----------
step "Create/activate venv"
if [[ ! -d "$ART_DIR/venv" ]]; then
  python -V
  python -m venv "$ART_DIR/venv"
fi
# shellcheck disable=SC1091
source "$ART_DIR/venv/bin/activate"

step "pip versions"
python -V
pip --version || true

# ---------- install deps (verbose) ----------
step "pip install requirements, pyarmor, pyinstaller"
pip install -vvv --upgrade pip
pip install -vvv -r requirements.txt pyarmor pyinstaller

step "Tool versions"
pyinstaller --version || true
pyarmor --version || true

# ---------- incremental helpers ----------
fingerprint() {
  # usage: fingerprint <files...>  -> prints single sha256
  local files=()
  for f in "$@"; do [[ -f "$f" ]] && files+=("$f"); done
  [[ ${#files[@]} -eq 0 ]] && { echo "0"; return; }
  # stable ordering by path
  sha256sum "${files[@]}" 2>/dev/null | sort -k2 | sha256sum | awk '{print $1}'
}

changed() {
  # usage: changed <cache_file> <new_fp>
  local cache="$1"; local newfp="$2"; local oldfp=""
  [[ -f "$cache" ]] && oldfp="$(cat "$cache" 2>/dev/null || true)"
  [[ "$newfp" != "$oldfp" ]]
}

save_fp() { echo "$2" > "$1"; }

# ---------- build collect-all flags from requirements.txt ----------
step "Generate --collect-all flags from requirements.txt"
REQ_FILE="requirements.txt"
COLLECT_FLAGS=()
if [[ -f "$REQ_FILE" ]]; then
  MAP_PKGS=$(python - <<'PY'
import re
names=set()
for raw in open("requirements.txt", encoding="utf-8"):
    line=raw.strip()
    if not line or line.startswith("#"): continue
    line=line.split("#",1)[0].strip()
    line=line.split(";",1)[0].strip()
    m=re.match(r'([A-Za-z0-9_.\-+]+)', line)
    if not m: continue
    name=m.group(1).split("[",1)[0]
    if name in ("-e",".","src"): continue
    if name.startswith(("git+","http://","https://","file:")): continue
    names.add(name)
for n in sorted(names):
    print(n)
PY
)
  while IFS= read -r pkg; do
    [[ -n "$pkg" ]] || continue
    COLLECT_FLAGS+=( --collect-all "$pkg" )
  done <<< "$MAP_PKGS"
else
  echo "WARN: requirements.txt not found; using minimal collect set"
  COLLECT_FLAGS+=( --collect-all fastapi --collect-all starlette --collect-all pydantic --collect-all anyio --collect-all uvicorn )
fi
# common extra
COLLECT_FLAGS+=( --collect-all psutil --collect-all cryptography )
printf 'collect-all flags: %q ' "${COLLECT_FLAGS[@]}"; echo

# ---------- hidden-import autodetect via AST ----------
step "Detect hidden imports from sources"
py_hidden_imports() {
python - "$@" <<'PY'
import ast, sys, pathlib
mods=set()
for p in sys.argv[1:]:
    src=pathlib.Path(p).read_text(encoding='utf-8')
    tree=ast.parse(src, filename=p)
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                mods.add(a.name.split('.')[0])
        elif isinstance(n, ast.ImportFrom):
            if n.module:
                mods.add(n.module.split('.')[0])
mods |= {
    "platform","asyncio","typing","pathlib","logging","json","re","time","datetime",
    "http","socket","subprocess","threading","concurrent","importlib","pkgutil","inspect",
    "uvicorn","fastapi","starlette","pydantic","anyio","sniffio","typing_extensions",
    "requests","httpx","psutil","cryptography"
}
print("\n".join(sorted(mods)))
PY
}
to_pyinstaller_flags() { awk '{print "--hidden-import="$0}' | xargs; }

ROOTD_IMPORTS=$(py_hidden_imports services/rootd.py)
HUB_IMPORTS=$(py_hidden_imports services/hub_proxy.py)
ROOTD_HIDDEN_FLAGS=$(echo "$ROOTD_IMPORTS" | to_pyinstaller_flags)
HUB_HIDDEN_FLAGS=$(echo "$HUB_IMPORTS" | to_pyinstaller_flags)
[[ -f services/rootd_linux.py ]] && ROOTD_HIDDEN_FLAGS="$ROOTD_HIDDEN_FLAGS --hidden-import=rootd_linux"
[[ -f services/rootd_win.py   ]] && ROOTD_HIDDEN_FLAGS="$ROOTD_HIDDEN_FLAGS --hidden-import=rootd_win"
ROOTD_HIDDEN_FLAGS="$ROOTD_HIDDEN_FLAGS --hidden-import=pyarmor_runtime"
echo "ROOTD hidden-imports flags: $ROOTD_HIDDEN_FLAGS"
echo "HUB   hidden-imports flags: $HUB_HIDDEN_FLAGS"

# ---------- fingerprints ----------
ROOTD_SRC=(services/rootd.py)
[[ -f services/rootd_linux.py ]] && ROOTD_SRC+=(services/rootd_linux.py)
[[ -f services/rootd_win.py   ]] && ROOTD_SRC+=(services/rootd_win.py)
[[ "$REBUILD_ON_REQ_CHANGE" == "1" && -f requirements.txt ]] && ROOTD_SRC+=(requirements.txt)

HUB_SRC=(services/hub_proxy.py)
[[ "$REBUILD_ON_REQ_CHANGE" == "1" && -f requirements.txt ]] && HUB_SRC+=(requirements.txt)

FP_ROOTD_NEW="$(fingerprint "${ROOTD_SRC[@]}")"
FP_HUB_NEW="$(fingerprint "${HUB_SRC[@]}")"
FP_ROOTD_FILE="$CACHE_DIR/.fp_rootd"
FP_HUB_FILE="$CACHE_DIR/.fp_hub"

ROOTD_DIST="$ART_DIR/rootd/dist/rootd"
HUB_DIST="$ART_DIR/hub_proxy/dist/hub_proxy"

NEED_BUILD_ROOTD="$FORCE"
NEED_BUILD_HUB="$FORCE"

if [[ "$NEED_BUILD_ROOTD" == "0" ]]; then
  if [[ ! -x "$ROOTD_DIST" ]] || changed "$FP_ROOTD_FILE" "$FP_ROOTD_NEW"; then
    NEED_BUILD_ROOTD=1
  fi
fi
if [[ "$NEED_BUILD_HUB" == "0" ]]; then
  if [[ ! -x "$HUB_DIST" ]] || changed "$FP_HUB_FILE" "$FP_HUB_NEW"; then
    NEED_BUILD_HUB=1
  fi
fi

echo "Fingerprint rootd: $FP_ROOTD_NEW (changed=$([[ $NEED_BUILD_ROOTD == 1 ]] && echo yes || echo no))"
echo "Fingerprint hub   : $FP_HUB_NEW (changed=$([[ $NEED_BUILD_HUB == 1 ]] && echo yes || echo no))"

# ---------- PyArmor obfuscation (incremental) ----------
export PYARMOR_LOGLEVEL=DEBUG
: "${PYTHONPATH:=}"

if [[ "$NEED_BUILD_ROOTD" == "1" ]]; then
  step "PyArmor: obfuscate rootd (+platform)"
  pyarmor gen -O "$ART_DIR/rootd" "${ROOTD_SRC[@]}"
else
  echo "Skip PyArmor rootd: sources unchanged & dist exists"
fi

if [[ "$NEED_BUILD_HUB" == "1" ]]; then
  step "PyArmor: obfuscate hub_proxy"
  pyarmor gen -O "$ART_DIR/hub_proxy" services/hub_proxy.py
else
  echo "Skip PyArmor hub_proxy: sources unchanged & dist exists"
fi

# ---------- PyInstaller (incremental) ----------
export PYTHONPATH="$ART_DIR/rootd:$ART_DIR/hub_proxy:$PYTHONPATH"

if [[ "$NEED_BUILD_ROOTD" == "1" ]]; then
  step "PyInstaller: build rootd"
  pyinstaller "$ART_DIR/rootd/rootd.py" \
    --onefile --noconfirm --clean \
    --log-level=DEBUG \
    "${COLLECT_FLAGS[@]}" \
    $ROOTD_HIDDEN_FLAGS \
    --distpath "$ART_DIR/rootd/dist" \
    --workpath "$ART_DIR/rootd/build"
  save_fp "$FP_ROOTD_FILE" "$FP_ROOTD_NEW"
else
  echo "Skip PyInstaller rootd"
fi

if [[ "$NEED_BUILD_HUB" == "1" ]]; then
  step "PyInstaller: build hub_proxy"
  pyinstaller "$ART_DIR/hub_proxy/hub_proxy.py" \
    --onefile --noconfirm --clean \
    --log-level=DEBUG \
    "${COLLECT_FLAGS[@]}" \
    $HUB_HIDDEN_FLAGS \
    --distpath "$ART_DIR/hub_proxy/dist" \
    --workpath "$ART_DIR/hub_proxy/build"
  save_fp "$FP_HUB_FILE" "$FP_HUB_NEW"
else
  echo "Skip PyInstaller hub_proxy"
fi

# ---------- Summarize PyInstaller warnings ----------
step "Summarize PyInstaller warnings"
for f in "$ART_DIR"/rootd/build/rootd/warn-*.txt "$ART_DIR"/hub_proxy/build/hub_proxy/warn-*.txt; do
  [[ -f "$f" ]] || continue
  echo "--- $(basename "$f") ---"
  sed -n '1,200p' "$f"
done

# ---------- Archive (include CLI) ----------
step "Archive: gptadmin.tar.gz"
# Тарим только существующие папки (на случай первой частичной сборки)
pushd "$ART_DIR" >/dev/null
INCLUDE=()
for d in rootd hub_proxy cli; do [[ -d "$d" ]] && INCLUDE+=("$d"); done
tar -czf gptadmin.tar.gz "${INCLUDE[@]}"

# NEW: компонентные архивы (если есть соответствующие папки)
step "Archive: per-component tarballs"
if [[ -d hub_proxy ]]; then
  tar -czf gptadmin-hub.tar.gz hub_proxy
  echo "built: $ART_DIR/gptadmin-hub.tar.gz"
else
  echo "WARN: hub_proxy dir not found, skip gptadmin-hub.tar.gz"
fi

if [[ -d rootd ]]; then
  tar -czf gptadmin-rootd.tar.gz rootd
  echo "built: $ART_DIR/gptadmin-rootd.tar.gz"
else
  echo "WARN: rootd dir not found, skip gptadmin-rootd.tar.gz"
fi

# полезно увидеть размеры
ls -lh gptadmin*.tar.gz 2>/dev/null || true
popd >/dev/null


# ---------- Smoke tests ----------
wait_for_http() {
  # wait_for_http URL [timeout_seconds] [extra_curl_args...]
  local url="$1"; local timeout="${2:-20}"; shift 2 || true
  local attempt
  for ((attempt=1; attempt<=timeout; attempt++)); do
    # ВАЖНО: НЕ используем -f — нам достаточно ЛЮБОГО HTTP-ответа (даже 404/401),
    # чтобы понять, что сервер уже поднялся и отвечает.
    if curl -sS "$url" "$@" -o /dev/null; then
      echo "HTTP OK: $url (attempt $attempt/$timeout)"
      return 0
    fi
    sleep 1
  done
  echo "Timeout waiting for $url"
  return 1
}
wait_for_listen_port() {
  # wait_for_listen_port PORT [timeout_seconds]
  local port="$1"; local timeout="${2:-20}"
  local attempt line
  for ((attempt=1; attempt<=timeout; attempt++)); do
    line="$(ss -ltn "( sport = :$port )" 2>/dev/null | sed -n '2p' || true)"
    if [[ -n "$line" ]]; then
      echo "LISTEN OK: :$port (attempt $attempt/$timeout)"
      return 0
    fi
    sleep 1
  done
  echo "Timeout waiting for port :$port to listen"
  return 1
}


# Возвращает 0 если порт ЗАНЯТ, 1 если свободен (без падений при set -e)
is_port_busy() {
  local port="$1"
  local line out
  if command -v ss >/dev/null 2>&1; then
    line="$(ss -ltn "( sport = :$port )" 2>/dev/null | sed -n '2p' || true)"
    [[ -n "$line" ]]
  elif command -v lsof >/dev/null 2>&1; then
    out="$(lsof -nP -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)"
    [[ -n "$out" ]]
  else
    return 1  # не можем проверить — считаем свободным
  fi
}

# Выбирает base или base+1. Если оба заняты — падаем с понятной ошибкой.
pick_port_plus1() {
  local base="$1"
  if is_port_busy "$base"; then
    local alt=$((base+1))
    if is_port_busy "$alt"; then
      echo "ERROR: ports $base и $alt заняты" >&2
      exit 1
    fi
    echo "$alt"
  else
    echo "$base"
  fi
}


if [[ "$SKIP_TESTS" != "1" ]]; then
  [[ -x "$ROOTD_DIST" ]] || { echo "Missing $ROOTD_DIST"; exit 1; }
  [[ -x "$HUB_DIST"   ]] || { echo "Missing $HUB_DIST";   exit 1; }

    step "Smoke test: rootd"
    : > "$ROOTD_RT_LOG"
    ROOTD_PORT="$(pick_port_plus1 25900)"
    echo "Using ROOTD_PORT=$ROOTD_PORT"
    ROOTD_TOKEN=testtoken HUB_URL='' ROOTD_PORT="$ROOTD_PORT" \
    "$ROOTD_DIST" >"$ROOTD_RT_LOG" 2>&1 &
    ROOTD_PID=$!
    wait_for_http "http://127.0.0.1:${ROOTD_PORT}/system/health" 25 \
    -H "Authorization: Bearer testtoken"
    curl -sS -f -H "Authorization: Bearer testtoken" \
    "http://127.0.0.1:${ROOTD_PORT}/system/health" | grep -q uptime_s
    kill "$ROOTD_PID" || true
    ROOTD_PID=""

    step "Smoke test: hub_proxy"
    : > "$HUB_RT_LOG"
    HUB_PORT="$(pick_port_plus1 9001)"
    echo "Using HUB_PORT=$HUB_PORT"
    CTL_TOKEN=ctltest HUB_PORT="$HUB_PORT" \
    "$HUB_DIST" >"$HUB_RT_LOG" 2>&1 &
    HUB_PID=$!

    # 1) ждём, что порт начал слушать
    wait_for_listen_port "$HUB_PORT" 25

    # 2) ждём любой HTTP-ответ: сперва OpenAPI (публичный), если нет — /servers
    if ! wait_for_http "http://127.0.0.1:${HUB_PORT}/openapi.json" 10; then
    wait_for_http "http://127.0.0.1:${HUB_PORT}/servers" 10 -H "Authorization: Bearer ctltest"|| {
        echo "Hub API didn't respond on /openapi.json nor /servers"; exit 1; }
    fi

    # 3) регистрируем тестовый rootd и убеждаемся, что он появился
    curl -sS -f -X POST "http://127.0.0.1:${HUB_PORT}/heartbeat" \
    -H 'Content-Type: application/json' \
    -d "{\"name\":\"srv\",\"base_url\":\"http://127.0.0.1:${ROOTD_PORT}\",\"rootd_token\":\"x\",\"time\":0}" >/dev/null

    curl -sS -f "http://127.0.0.1:${HUB_PORT}/servers" -H "Authorization: Bearer ctltest"| grep -q srv

    kill "$HUB_PID" || true
    HUB_PID=""



else
  echo "Skip smoke tests (SKIP_TESTS=1)"
fi

step "DONE: Artifacts stored in $ART_DIR"
echo "Main log: $LOG"
echo "Runtime logs: $ROOTD_RT_LOG, $HUB_RT_LOG"
echo "Cache dir: $CACHE_DIR  (delete with CLEAN=1)"
